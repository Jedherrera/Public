Dictionatry Entry Herrera
